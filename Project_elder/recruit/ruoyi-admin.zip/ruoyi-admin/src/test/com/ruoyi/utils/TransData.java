package com.ruoyi.utils;

import lombok.Data;

@Data
public class TransData {
    /**
     * 原文
     */
    private String src;
    /**
     * 译文
     */
    private String dst;
}

